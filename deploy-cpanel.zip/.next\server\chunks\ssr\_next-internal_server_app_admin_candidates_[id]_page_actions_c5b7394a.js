module.exports=[69513,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_candidates_%5Bid%5D_page_actions_c5b7394a.js.map