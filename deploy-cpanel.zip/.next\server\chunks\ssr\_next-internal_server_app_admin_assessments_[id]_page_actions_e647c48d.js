module.exports=[87168,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_assessments_%5Bid%5D_page_actions_e647c48d.js.map