module.exports=[31496,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_narrative_route_actions_f4ad9482.js.map