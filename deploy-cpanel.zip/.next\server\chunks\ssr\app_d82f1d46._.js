module.exports=[71105,a=>{a.v("/_next/static/media/icon.f7852fd9.jpg")},63447,a=>{"use strict";let b={src:a.i(71105).default,width:1024,height:1024};a.s(["default",0,b])}];

//# sourceMappingURL=app_d82f1d46._.js.map