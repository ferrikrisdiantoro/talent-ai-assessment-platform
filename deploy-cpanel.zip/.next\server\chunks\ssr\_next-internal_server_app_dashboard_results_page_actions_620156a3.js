module.exports=[40949,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_results_page_actions_620156a3.js.map