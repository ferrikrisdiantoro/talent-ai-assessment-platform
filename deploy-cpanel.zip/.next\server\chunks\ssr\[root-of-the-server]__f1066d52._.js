module.exports=[14747,(a,b,c)=>{b.exports=a.x("path",()=>require("path"))},96221,a=>{"use strict";let b=(0,a.i(70106).default)("loader-circle",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]]);a.s(["Loader2",()=>b],96221)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__f1066d52._.js.map