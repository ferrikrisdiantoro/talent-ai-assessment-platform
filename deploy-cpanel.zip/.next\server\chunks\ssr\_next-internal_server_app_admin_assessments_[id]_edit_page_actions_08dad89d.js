module.exports=[83146,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_assessments_%5Bid%5D_edit_page_actions_08dad89d.js.map