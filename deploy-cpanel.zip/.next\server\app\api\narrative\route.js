var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/narrative/route.js")
R.c("server/chunks/[root-of-the-server]__a6d89067._.js")
R.c("server/chunks/node_modules_next_c5729131._.js")
R.c("server/chunks/[root-of-the-server]__898b8e35._.js")
R.c("server/chunks/_b3756c1f._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_7317f5c9.js")
R.c("server/chunks/_next-internal_server_app_api_narrative_route_actions_f4ad9482.js")
R.m(14257)
module.exports=R.m(14257).exports
