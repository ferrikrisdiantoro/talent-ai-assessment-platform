var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/auth/callback/route.js")
R.c("server/chunks/[root-of-the-server]__9536a046._.js")
R.c("server/chunks/node_modules_next_c5729131._.js")
R.c("server/chunks/_b3756c1f._.js")
R.c("server/chunks/[root-of-the-server]__2c6297a5._.js")
R.c("server/chunks/_next-internal_server_app_auth_callback_route_actions_3740e4d4.js")
R.m(76907)
module.exports=R.m(76907).exports
