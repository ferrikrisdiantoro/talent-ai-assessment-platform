module.exports=[65303,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_candidates_page_actions_b3ac7c2e.js.map