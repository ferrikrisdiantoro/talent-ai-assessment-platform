module.exports=[46809,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_assessments_new_page_actions_869517d1.js.map