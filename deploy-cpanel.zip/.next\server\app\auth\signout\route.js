var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/auth/signout/route.js")
R.c("server/chunks/[root-of-the-server]__55d97030._.js")
R.c("server/chunks/node_modules_next_d2a0bda1._.js")
R.c("server/chunks/_b3756c1f._.js")
R.c("server/chunks/[root-of-the-server]__275f4eb5._.js")
R.c("server/chunks/_next-internal_server_app_auth_signout_route_actions_56222305.js")
R.m(61675)
module.exports=R.m(61675).exports
